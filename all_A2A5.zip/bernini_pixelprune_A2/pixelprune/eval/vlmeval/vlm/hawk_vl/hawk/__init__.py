from .model import HawkQwenForCausalLM
